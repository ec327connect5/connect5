package com.example.connectfive;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.connectfive.R;
import com.example.connectfive.game;

public class MainActivity extends Activity {
    //board size
    final static int size = 15;
    private Context context;

    //imageview array
    private ImageView[][] cells = new ImageView[size][size];

    private Drawable[] drawCell=new Drawable[4];

    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        loadResources();
        designGame();
        /*
        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                designGame();


            }

        });
*/
    }

    private void loadResources(){
        drawCell [3] = context.getResources().getDrawable(R.drawable.cell_bg); //background
        //2 images for players
        drawCell [0] = null;
        drawCell [1] = context.getResources().getDrawable(R.drawable.black);
        drawCell [2] = context.getResources().getDrawable(R.drawable.white);
    }
    void startGame(){
        Intent intent = new Intent(this, game.class);
        startActivity(intent);
    }

        private void designGame(){
            //creates layout parameters
            startGame();
            int cellSize = Math.round(ScreenWidth()/size);
            LinearLayout.LayoutParams lprow = new LinearLayout.LayoutParams(cellSize*size, cellSize);
            LinearLayout.LayoutParams lpcell = new LinearLayout.LayoutParams(cellSize, cellSize);

            LinearLayout linBoardGame = (LinearLayout) findViewById(R.id.linBoardGame);

            //create cells
            for(int i=0;i<size;i++){
                LinearLayout linRow = new LinearLayout(context);
                //make a row
                for(int j=0;j<size;j++){
                    cells[i][j]=new ImageView(context);
                    //make cell
                    //set background default for cell
                    cells[i][j].setBackground(drawCell[3]);
                    linRow.addView(cells[i][j],lpcell);
                }
                linBoardGame.addView(linRow,lprow);
            }

        }

    private float ScreenWidth(){
        Resources resources = context.getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        return dm.widthPixels;
    }

}