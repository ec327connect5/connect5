package com.example.connectfive;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;



public class MainActivity extends Activity {
    //board size
    final static int size = 15;
    private Context context;

    private Button start;
    private TextView turn;
    private int[][] valueCell = new int[size][size];
    private int winner; //0(tie), 1(p1), 2(p2)
    private boolean firstMove;
    private int playerTurn;
    private int xMove, yMove;
    public MainActivity(){}

    //imageview array
    private ImageView[][] cells = new ImageView[size][size];

    private Drawable[] drawCell=new Drawable[4];



    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        setListen();
        loadResources();
        designGame();

    }

    @SuppressLint("SetTextI18n")
    private void setListen(){
        start = (Button) findViewById(R.id.start);
        turn = (TextView) findViewById(R.id.turn);
        start.setText("Play Game");
        turn.setText("Press button to play game");
        start.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                initGame();
                playGame();
            }

        });
    }

    private void playGame(){
    //define who goes first
        start = (Button) findViewById(R.id.start);
        start.setText("Start Over");
        Random r = new Random();
        playerTurn = r.nextInt(2) + 1; //returns value from 0-1
        if (playerTurn == 1){
            Toast.makeText(context, "Player 1 goes First", Toast.LENGTH_SHORT).show();
            pOneTurn();
        }
        else{
            Toast.makeText(context, "Player 2 goes First", Toast.LENGTH_SHORT).show();
            pTwoTurn();
        }

    }

    private void pOneTurn(){
        if(firstMove){
            firstMove=true;
            make_a_move();
        } else{
            turn.setText("Player 1");
            isClicked=false;
        }
    }


    @SuppressLint("SetTextI18n")
    private void make_a_move() {
        cells[xMove][yMove].setImageDrawable(drawCell[playerTurn]);
        valueCell[xMove][yMove]=playerTurn;
        //check if anyone wins
        //if no empty cells exist then draw
        if(noEmptyCell()){
            Toast.makeText(context, "Draw!", Toast.LENGTH_SHORT).show();
            return;
        }else if(CheckWinner()) {
            if(winner==1){
                Toast.makeText(context, "Winner is Player 1", Toast.LENGTH_SHORT).show();
                turn.setText("Winner is Player 1");
            } else {
                Toast.makeText(context, "Winner is Player 2", Toast.LENGTH_SHORT).show();
                turn.setText("Winner is Player 2");
            }
            return;
        }

        if(playerTurn==1){
            playerTurn=(1+2)-playerTurn;
            pOneTurn();
        }else{
            playerTurn=3-playerTurn;
            pTwoTurn();
        }
    }

    private boolean CheckWinner() {
        //checks if recent move makes a 5 in a row
        if(winner!=0) return true;
        //check row
        VectorEnd(xMove,0,0,1,xMove,yMove);
        //check column
        VectorEnd(0,yMove,1,0,xMove,yMove);
        //check left to right
        if(xMove+yMove>=size-1){
            VectorEnd(size-1,xMove+yMove-size+1,-1,1,xMove,yMove);
        }else{
            VectorEnd(xMove+yMove,0,-1,1,xMove,yMove);
        }
        //check right to left
        if(xMove<=yMove){
            VectorEnd(xMove-yMove+size-1,size-1,-1,-1,xMove,yMove);
        } else{
            VectorEnd(size-1,size-1-(xMove-yMove),-1,-1,xMove,yMove);
        }
        if(winner!=0) return true; else return false;
    }

    private void VectorEnd(int xx, int yy, int vx, int vy, int rx, int ry) {
        //this function checks row
        if(winner!=0) return;
        final int range=4;
        int i,j;
        int xbelow=rx-range*vx;
        int ybelow=ry-range*vy;
        int xabove=rx+range*vx;
        int yabove=ry+range*vy;
        String st="";
        i=xx;
        j=yy;
        while(inside(i, xbelow, xabove) || inside(j, ybelow, yabove)){
            i+=vx; j+=vy;
        }
        while(true){
            st=st+String.valueOf(valueCell[i][j]);
            if(st.length()==5){
                EvalEnd(st);
                st=st.substring(1,5); //substring of st from index 1-5
            }
            i+=vx;
            j+=vy;
            if(!inBoard(i,j) || inside(i, xbelow, xabove) || inside(j, ybelow, yabove) || winner!=0){
                break;
            }
        }
    }

    private boolean inBoard(int i, int j) {
        //checks to see if i,j is on the board
        if(i<0 || i>size-1 || j<0 || j>size-1) return false;
        return true;
    }

    private void EvalEnd(String st) {
        switch (st){
            case "11111": winner=1; break;
            case "22222": winner=2; break;
            default:break;
        }
    }

    private boolean inside(int i, int xbelow, int xabove) { //checks to see if i is in (xabove or xbelow or not)
        return (i - xbelow) * (i - xabove) > 0;
    }

    private boolean noEmptyCell() {
        for(int i=0;i<size;i++){
            for(int j=0;j<size;j++)
                if(valueCell[i][j]==0)
                    return false;
        }
        return true;
    }

    @SuppressLint("SetTextI18n")
    private void pTwoTurn(){
        turn.setText("Player 2");
        firstMove=false;
        isClicked=false;
    }

    private void initGame(){
        firstMove = true;
        winner = 0;
        for(int i=0;i<size;i++)
        {
            for (int j = 0; j < size; j++) {
                cells[i][j].setImageDrawable(drawCell[0]); //default or empty cell
                valueCell[i][j]=0;
            }
        }
    }
    @SuppressLint("UseCompatLoadingForDrawables")
    private void loadResources(){
        drawCell [3] = context.getResources().getDrawable(R.drawable.cell_bg); //background
        //2 images for players
        drawCell [0] = null;
        drawCell [1] = context.getResources().getDrawable(R.drawable.black);
        drawCell [2] = context.getResources().getDrawable(R.drawable.white);
    }

        private boolean isClicked; //tracks if player clicks cell or not
        @SuppressLint("NewApi")
        private void designGame(){
            //creates layout parameters
            int cellSize = Math.round(ScreenWidth()/size);
            LinearLayout.LayoutParams lprow = new LinearLayout.LayoutParams(cellSize*size, cellSize);
            LinearLayout.LayoutParams lpcell = new LinearLayout.LayoutParams(cellSize, cellSize);

            LinearLayout linBoardGame = (LinearLayout) findViewById(R.id.linBoardGame);

            //create cells
            for(int i=0;i<size;i++){
                LinearLayout linRow = new LinearLayout(context);
                //make a row
                for(int j=0;j<size;j++){
                    cells[i][j]=new ImageView(context);
                    //make cell
                    //set background default for cell
                    cells[i][j].setBackground(drawCell[3]);
                    final int x=i;
                    final int y=j;

                    cells[i][j].setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View v) {
                            if (valueCell[x][y]==0){ //empty cell
                                if (!isClicked) {
                                    isClicked = true;
                                    xMove = x;
                                    yMove = y;
                                    make_a_move();
                                }
                            }
                        }
                    });
                    linRow.addView(cells[i][j],lpcell);

                }
                linBoardGame.addView(linRow,lprow);
            }

        }

    private float ScreenWidth(){
        Resources resources = context.getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        return dm.widthPixels;
    }

}